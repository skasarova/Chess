﻿using Chess.Code.Board;
using Chess.Code.Pieces;
using System;

namespace Chess
{
    class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}